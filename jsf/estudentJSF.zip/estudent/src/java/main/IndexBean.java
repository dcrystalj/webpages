/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import database.Connect;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import database.Connect;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author Crystal
 */
@ManagedBean
@RequestScoped
public class IndexBean {

    @ManagedProperty(value="#{param.page}")
    private String page;
    /**
     * Creates a new instance of index
     */
    public IndexBean() {
    }
    public int getUserRights() throws SQLException, IOException{
        int i = Integer.parseInt(getUserId());
        Connect c = new Connect();
        Connection conn = c.makeConnection();
        Statement statement = conn.createStatement();
        String sql="SELECT * FROM user WHERE id="+i;
        ResultSet rs = statement.executeQuery(sql);
        while(rs.next()){
            int status = rs.getInt("status");
            return status;
        }
        rs.close();
        FacesContext.getCurrentInstance().getExternalContext().redirect("login.xhtml");
        return 0;
    }
    public String getUserId(){
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest();
        HttpSession httpSession = request.getSession(false);
        String sessionId = (String)httpSession.getAttribute("userid");
        return sessionId;
    }

    /**
     * @return the page
     */
    public String getPage() {
        return page;
    }

    /**
     * @param page the page to set
     */
    public void setPage(String page) {
        this.page = page;
    }
}
