/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import database.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Crystal
 */
@ManagedBean
@RequestScoped
public class UserBean {

    /**
     * Creates a new instance of UserBean
     */
    private String id;
    private String mail;
    private String name;
    private String surname;

    public UserBean() throws SQLException {

    }
    public void initBean() throws SQLException{
        id=getUserId();
        int i = Integer.parseInt(id);
        Connect c = new Connect();
        Connection conn = c.makeConnection();
        Statement statement = conn.createStatement();
        String sql="SELECT mail,name,surname,status FROM user WHERE id=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        try {
          ps.setString(1, id);
          ResultSet rs = ps.executeQuery();
          while(rs.next()) {

            this.mail = rs.getString("mail");
            name = rs.getString("name");
            surname = rs.getString("surname");
          }
        } finally {
          try { ps.close(); } catch (Exception ignore) {}
        }
    }
    
    /**
     * @return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * @param surname the surname to set
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }
    public String getUserId(){
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest();
        HttpSession httpSession = request.getSession(false);
        String sessionId = (String)httpSession.getAttribute("userid");
        return sessionId;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }
}
