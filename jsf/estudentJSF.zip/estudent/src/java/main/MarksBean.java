/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import database.Connect;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.CachedRowSet;

/**
 *
 * @author Crystal
 */
@ManagedBean
@RequestScoped
public class MarksBean {

    /**
     * Creates a new instance of marks
     */
    public MarksBean() {
    }
    public ResultSet getMarks() throws SQLException{
        String id=getUserId();
        int i = Integer.parseInt(id);
        Connect c = new Connect();
        Connection conn = c.makeConnection();
        String sql="SELECT mark.subject subject, mark.mark mark, mark.year year, subject.name name  FROM mark LEFT JOIN subject on mark.subject=subject.id WHERE mark.user=? ORDER BY mark.subject";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, id);
        CachedRowSet rowSet = new com.sun.rowset.CachedRowSetImpl();
        rowSet.populate( ps.executeQuery() );
        return rowSet;
    }

    public String getUserId(){
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest();
        HttpSession httpSession = request.getSession(false);
        String sessionId = (String)httpSession.getAttribute("userid");
        return sessionId;
    }

}
