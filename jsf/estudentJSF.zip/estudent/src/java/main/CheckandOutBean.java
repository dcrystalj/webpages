/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import database.Connect;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.CachedRowSet;
import javax.swing.ListCellRenderer;

/**
 *
 * @author Crystal
 */
@ManagedBean
@RequestScoped
public class CheckandOutBean {

    /**
     * Creates a new instance of CheckandOutBean
     */
    private String resid;

    public CheckandOutBean() {
    }

    public ListCheck[] getCheckExams() throws SQLException{
        String id=getUserId();
        int i = Integer.parseInt(id);
        Connect c = new Connect();
        Connection conn = c.makeConnection();
        String sql = "SELECT subject.id id, subject.name name FROM subject LEFT JOIN mark ON subject.id=mark.subject WHERE subject.examon=1 and subject.id NOT IN (select mark.subject FROM mark WHERE mark.user=?) AND subject.id NOT IN (select subject from exam where user=?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, id);
        ps.setString(2, id);
        ResultSet rs = ps.executeQuery();
        rs.last();
        int numrows = rs.getRow();
        ListCheck[] lc = new ListCheck[numrows];
        rs.beforeFirst();
        i=0;
        while(rs.next()) {
           lc[i]=new ListCheck(rs.getString("id"),rs.getString("name"));
           i++;
        }
        return lc;
    }
        public ListCheck[] getCheckoutExams() throws SQLException{
        String id=getUserId();
        int i = Integer.parseInt(id);
        Connect c = new Connect();
        Connection conn = c.makeConnection();
        String sql = "SELECT subject.name name, exam.subject id  FROM exam LEFT JOIN subject ON subject.id=exam.subject WHERE exam.user=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        rs.last();
        int numrows = rs.getRow();
        ListCheck[] lc = new ListCheck[numrows];
        rs.beforeFirst();
        i=0;
        while(rs.next()) {
           lc[i]=new ListCheck(rs.getString("id"),rs.getString("name"));
           i++;
        }
        return lc;
    }
    public String getUserId(){
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest();
        HttpSession httpSession = request.getSession(false);
        String sessionId = (String)httpSession.getAttribute("userid");
        return sessionId;
    }

    /**
     * @return the resid
     */
    public String getResid() {
        return resid;
    }

    /**
     * @param resid the resid to set
     */
    public void setResid(String resid) {
        this.resid = resid;
    }

    /**
     * @return the resname
     */

    public String insertCheck(){
        System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        try
        {
            Connect c = new Connect();
            Connection conn = c.makeConnection();
            Statement statement = conn.createStatement();

            System.out.println("Inserted records into the table...");
            String sql="INSERT INTO exam VALUES ('','"+resid+"','"+getUserId()+"')";
            statement.executeUpdate(sql);

            System.out.println("Inserted records into the table...");

            return "uspešen vpis";
        }catch(Exception e){

        }
        return "";
    }
}
