/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import java.io.Serializable;
import database.Connect;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.context.FacesContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *
 * @author Crystal
 */
@ManagedBean
@RequestScoped
public class LoginBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private String username;
    private String passwd;
    private Boolean remember;
    public LoginBean() {
        remember=false;
        username="";
        passwd="";
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the passwd
     */
    public String getPasswd() {
        return passwd;
    }

    /**
     * @param passwd the passwd to set
     */
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    /**
     * @return the remember
     */
    public Boolean getRemember() {
        return remember;
    }

    /**
     * @param remember the remember to set
     */
    public void setRemember(Boolean remember) {
        this.remember = remember;
    }

    public String Valid() throws SQLException, IOException{
        Connect c = new Connect();
        Connection conn = c.makeConnection();
        Statement statement = conn.createStatement();
        try{
            int i = Integer.parseInt(username);
        }catch(Exception e){
            return "fail";
        }

        String sql="SELECT * FROM user WHERE id="+username+" AND passwd='"+passwd+"'";
        ResultSet rs = statement.executeQuery(sql);
        while(rs.next()){
            FacesContext context = FacesContext.getCurrentInstance();
            HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest();
            HttpSession httpSession = request.getSession(false);
            httpSession.setAttribute("userid", username);
            FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");
            return "sucess";
        }
        rs.close();
        return "fail";
    }
    public String getInvalid()throws SQLException, IOException{
        if("".equals(username) || "".equals(passwd) ){
		return "";
	   }else{
		return "Napacni podatki";
	   }
    }
}
