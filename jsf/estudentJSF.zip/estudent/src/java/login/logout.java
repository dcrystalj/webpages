/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.io.IOException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.jms.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Crystal
 */
@ManagedBean
@RequestScoped
public class logout {

    /**
     * Creates a new instance of logout
     */
    public logout() throws IOException {
       FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest();
        HttpSession httpSession = request.getSession(false);
        httpSession.invalidate();
        FacesContext.getCurrentInstance().getExternalContext().redirect("login.xhtml");
    }
}
