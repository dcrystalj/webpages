package database;
import com.mysql.jdbc.Driver;
import java.sql.*;
/**
 *
 * @author Ferdiansyah Dolot
 */
public class Connect {
    public Connect() throws SQLException{
        makeConnection();
    }

    private Connection koneksi;

     public  Connection makeConnection() throws SQLException {
        if (koneksi == null) {
             new Driver();
            // buat koneksi
             koneksi = DriverManager.getConnection(
                       "jdbc:mysql://mysql.lrk.si/tt3710",
                       "tt3710",
                       "tt3710");
         }
         return koneksi;
     }

     public static void main(String args[]) {
         try {
             Connect c = new Connect();
         }
         catch (SQLException e) {
             e.printStackTrace();
         }

    }
}